document.addEventListener("DOMContentLoaded", function () {
    // Pop-up mission
    const missionPopup = document.getElementById("mission-popup");
    if (missionPopup) {
        setTimeout(() => {
            missionPopup.classList.add("hidden");
        }, 3000);
    }

    // Task Bar Elements for Objectives
    const farmTask = document.getElementById("farm-task");
    const radiationTask = document.getElementById("radiation-task");
    const domeTask = document.getElementById("dome-task");

    const farmStatus = document.getElementById("farm-status");
    const radiationStatus = document.getElementById("radiation-status");
    const domeStatus = document.getElementById("dome-status");

    // Hint Button Logic with Hint Counter
    const hintButton = document.getElementById("hint-button");
    const hintContent = document.getElementById("hint-content");
    const hintText = document.getElementById("hint-text");
    const hintCounter = document.getElementById("hint-counter");
    let unlockedItems = 0;
    let availableHints = 0;
    const unlockThreshold = 5;

    // Reference to sound elements
    const correctSound = document.getElementById("correct-sound");
    const errorSound = document.getElementById("error-sound");

    // Sample hints
    const hints = [
        "Combining sunlight and rock will give you the power of a star.",
        "Did you know that life first formed from the sea?",
        "Keep slowly growing the soil to transform it into a hydroponic farm.",
        "Science holds the key to building a powerful Radiation Deflector. You got this!",
        "Have you used glass and rock to create a safe structure that will protect your colony?"
    ];

    // Facts associated with items created
    const itemFacts = {
        "Sun ☀️": "The Sun provides energy for plants and solar panels, making it a vital source of power for a Martian colony.",
        "Fire 🔥": "Fire is essential for warmth and cooking, but in a Martian environment, managing fire safely is crucial.",
        // Add more item facts as needed
    };

    const factBox = document.getElementById("fact-box");
    const factText = document.getElementById("fact-text");

    // Update hint counter display
    function updateHintCounter() {
        hintCounter.textContent = `Hints available: ${availableHints}`;
    }

    // Function to show a hint
    function showHint() {
        if (availableHints > 0) {
            hintText.textContent = hints[Math.floor(Math.random() * hints.length)];
            hintContent.classList.add("expanded");

            availableHints--;
            updateHintCounter();

            if (availableHints === 0) {
                hintButton.disabled = true;
            }
        }
    }

    // Add event listener to the hint button
    hintButton.addEventListener("click", showHint);

    // Function to award a hint
    function awardHint() {
        availableHints++;
        hintButton.disabled = false;
        updateHintCounter();
    }

    // Starting elements
    const items = {
        "Air": { name: "Air 💨", emoji: "💨" },
        "Sunlight": { name: "Sunlight 🔆", emoji: "🔆" },
        "Rock": { name: "Rock 🧱", emoji: "🧱" },
        "Ice": { name: "Ice 🧊", emoji: "🧊" }
    };

    // Updated combinations
    const combinations = {
        "🔆🧱": { newItem: { name: "Sun ☀️", emoji: "☀️", description: "A bright star vital for life!" } },
        "🧱🧱": { newItem: { name: "Fire 🔥", emoji: "🔥", description: "Fire is considered one of humanity's first technological innovations." } },
        "🔥💦": { newItem: { name: "Water Vapor 🌫️", emoji: " 🌫️", description: "Water vapor plays a crucial role in Earth's climate system." } },
        "🧊☀️": { newItem: { name: "Water 💦", emoji: "💦", description: "Water is the universal solvent, making it essential for life." } },
        "🔆💨": { newItem: { name: "Fire 🔥", emoji: "🔥", description: "Fire is considered one of humanity's first technological innovations." } },
        "🧊🔥": { newItem: { name: "Water 💦", emoji: "💦", description: "Water is the universal solvent, making it essential for life." } },
        "🧱💦": { newItem: { name: "Sand 🏜️", emoji: "🏜️", description: "Sand is a key ingredient in the production of glass, concrete, and silicon chips used in technology." } },
        "🧱💨": { newItem: { name: "Sand 🏜️", emoji: "🏜️", description: "Sand is a key ingredient in the production of glass, concrete, and silicon chips used in technology." } },
        "💨💨": { newItem: { name: "Whirlwind 🌬️", emoji: "🌬️", description: "Whirlwinds, also known as dust devils." } },
        "🌬️💦": { newItem: { name: "Tornado 🌪️", emoji: "🌪️", description: "Tornadoes are intense, rotating columns of air extending from a thunderstorm to the ground." } },
        "🧱🌪️": { newItem: { name: "Sand 🏜️", emoji: "🏜️", description: "Sand is a key ingredient in the production of glass, concrete, and silicon chips used in technology." } },
        "🏜️👽": { newItem: { name: "Soil 🌱", emoji: "🌱", description: "Nature’s snack bar for plants!" } },
        "👽🧱": { newItem: { name: "Soil 🌱", emoji: "🌱", description: "Nature’s snack bar for plants!" } },
        "💦🌱": { newItem: { name: "Nutrient 🥄", emoji: "🥄", description: "The plant superfood!" } },
        "🌱👽": { newItem: { name: "Nutrient 🥄", emoji: "🥄", description: "The plant superfood!" } },
        "🌱💦": { newItem: { name: "Food 🍎", emoji: "🍎", description: "The ultimate life fuel!" } },
        "🧱🔥": { newItem: { name: "Volcano 🌋", emoji: "🌋", description: "Earth’s pressure relief valve!" } },
        "🌋🌋": { newItem: { name: "Lava 🎇", emoji: "🎇", description: "Nature’s hot glue!" } },
        "🎇🌬️": { newItem: { name: "Glass 🥂", emoji: "🥂", description: "Super-cooled sand that went through a fiery makeover!" } },
        "🏜️🔥": { newItem: { name: "Glass 🥂", emoji: "🥂", description: "Super-cooled sand that went through a fiery makeover!" } },
        "🥂🥂": { newItem: { name: "Potion Bottle🔮", emoji: "🔮", description: "PThe magical container for mixing up all kinds of concoctions!" } },
        "💦🔆": { newItem: { name: "Rainbow 🌈", emoji: "🌈", description: "Nature’s prism party!" } },
        "💦💦": { newItem: { name: "Sea 🌊", emoji: "🌊", description: "Earth’s giant blue swimming pool!" } },
        "☀️🌊": { newItem: { name: "Life 👽", emoji: "👽", description: "The universe’s biggest experiment!" } },
        "👽🔮": { newItem: { name: "Science 🔬", emoji: "🔬", description: "Humanity’s curiosity toolkit!" } },
        "🔮🔬": { newItem: { name: "Trapping Gas Container 🥡", emoji: "🥡", description: "The airtight jar for sneaky gases!" } },
        "🌫️🥡": { newItem: { name: "Artificial Atmosphere 🔷", emoji: "🔷", description: "A custom-made sky!" } },
        "🌱💦": { newItem: { name: "Mud 🟫", emoji: "🟫", description: "Nature’s squishy building material!" } },
        "🟫🌱": { newItem: { name: "Hydroponic Plant 🥀", emoji: "🥀", description: "A water-loving green machine!" } },
        "🥀☀️": { newItem: { name: "Growing Plant 🌲", emoji: "🌲", description: "A solar-powered life factory!" } },
        "🥂🧱": { newItem: { name: "Dome 🏠", emoji: "🏠", description: "A giant bubble of safety!" } },
        "🥂🏡": { newItem: { name: "Dome 🏠", emoji: "🏠", description: "A giant bubble of safety!" } },
        "🏠🔷": { newItem: { name: "Pressurized Dome", emoji: "Pressurized Dome", description: "A high-tech life bubble!" } },
        "🥂🔥": { newItem: { name: "Greenhouse Structure 🏡", emoji: "🏡", description: "A glass house for growing goodies! " } },
        "🏡🌱": { newItem: { name: "Hydroponics Farm 👨‍🌾", emoji: "👨‍🌾", description: "Farming without the mess!" } },
        "🔬💨": { newItem: { name: "Radiation Deflector 📉", emoji: "📉", description: "A cosmic sunscreen!" } },
        "📉🥂": { newItem: { name: "Radiation Shield 🛡️", emoji: "🛡️", description: "Your space-age force field! It protects astronauts and habitats from dangerous cosmic rays, letting you explore the stars without getting zapped." } }

    };

    const inventory = document.getElementById("inventory-items");

    // Initialize inventory
    Object.keys(items).forEach(key => addItemToInventory(items[key].name, items[key].emoji));

    function addItemToInventory(itemName, emoji) {
        const item = document.createElement("div");
        item.classList.add("item");
        item.textContent = itemName;
        item.draggable = true;

        item.addEventListener("dragstart", e => {
            e.dataTransfer.setData("text/plain", emoji);
        });

        inventory.appendChild(item);

        unlockedItems++;
        if (unlockedItems % unlockThreshold === 0) {
            awardHint();
        }
    }

    // Drop Area Functionality
    const dropBox = document.getElementById("drop-box");
    const descriptionBox = document.getElementById("description-box");
    const descriptionText = document.getElementById("description-text");
    let placeholderVisible = true;

    function resetDropBox() {
        dropBox.innerHTML = "";
        const placeholder = document.createElement("p");
        placeholder.textContent = "Drop items here to combine";
        placeholder.classList.add("placeholder");
        dropBox.appendChild(placeholder);
        descriptionBox.style.display = "none";
        placeholderVisible = true;
        factBox.style.display = "none";
    }

    resetDropBox();

    dropBox.addEventListener("dragover", e => e.preventDefault());

    dropBox.addEventListener("drop", e => {
        e.preventDefault();
        const droppedItem = e.dataTransfer.getData("text/plain");

        const currentItems = dropBox.querySelectorAll('.item');
        
        if (currentItems.length >= 2) {
            const resultMessage = document.getElementById("result-message");
            resultMessage.textContent = "Only two items can be combined at a time!";
            return;
        }

        if (placeholderVisible) {
            const placeholder = dropBox.querySelector(".placeholder");
            if (placeholder) {
                placeholder.remove();
            }
            placeholderVisible = false;
        }

        const item = document.createElement("div");
        item.classList.add("item");
        item.textContent = droppedItem;
        dropBox.appendChild(item);

        const droppedItems = Array.from(dropBox.children).map(child => child.textContent);
        if (droppedItems.length === 2) {
            const item1 = droppedItems[0];
            const item2 = droppedItems[1];
            checkCombination(item1, item2);
        }
    });

    function checkCombination(item1, item2) {
        const combinedKey1 = item1 + item2;
        const combinedKey2 = item2 + item1;

        if (combinations[combinedKey1]) {
            correctSound.play();
            processCombination(combinations[combinedKey1]);
        } else if (combinations[combinedKey2]) {
            correctSound.play();
            processCombination(combinations[combinedKey2]);
        } else {
            errorSound.play();
            const resultMessage = document.getElementById("result-message");
            resultMessage.textContent = "No valid combination.";
        }
    }

    function processCombination(combination) {
        const newItem = combination.newItem;

        resetDropBox();

        const combinedItem = document.createElement("div");
        combinedItem.classList.add("item");
        combinedItem.textContent = newItem.emoji;
        dropBox.appendChild(combinedItem);

        const resultMessage = document.getElementById("result-message");
        resultMessage.textContent = `You created: ${newItem.name}!`;

        descriptionText.textContent = newItem.description;
        descriptionBox.style.display = "block";

        showFactForItem(newItem.name);

        if (newItem.name === "Hydroponics Farm 👨‍🌾") {
            markTaskComplete(farmTask, farmStatus);
        } else if (newItem.name === "Radiation Shield 🛡️") {
            markTaskComplete(radiationTask, radiationStatus);
        } else if (newItem.name === "Pressurized Dome") {
            markTaskComplete(domeTask, domeStatus);
        }

        if (!Object.values(items).some(existingItem => existingItem.emoji === newItem.emoji)) {
            items[newItem.description] = newItem;
            addItemToInventory(newItem.name, newItem.emoji);
        }

        checkAllTasksComplete();
    }

    function showFactForItem(itemName) {
        const fact = itemFacts[itemName] || "No fact available for this item.";
        factText.textContent = `Fun Fact: ${fact}`;
        factBox.style.display = "block";
    }

    function markTaskComplete(taskElement, statusElement) {
        taskElement.checked = true;
        statusElement.textContent = "(Complete)";
        statusElement.classList.remove("incomplete");
        statusElement.classList.add("complete");
    }

    function checkAllTasksComplete() {
        if (farmTask.checked && radiationTask.checked && domeTask.checked) {
            alert("Task completed, all the objectives have been cleared. You have successfully terraformed Mars!");
        }
    }

    const resetButton = document.querySelector(".reset-button");
    if (resetButton) {
        resetButton.addEventListener("click", () => {
            const resultMessage = document.getElementById("result-message");
            resultMessage.textContent = "";
            resetDropBox();
        });
    }
});


    // Facts associated with items created
    const itemFacts = {
        "Sun ☀️": "The Sun provides energy for plants and solar panels, making it a vital source of power for a Martian colony.",
        "Fire 🔥": "Fire is essential for warmth and cooking, but in a Martian environment, managing fire safely is crucial.",
        "Water Vapor 🌫️": "Water vapor can be condensed to obtain liquid water, which is essential for drinking and irrigation.",
        "Water 💦": "Water is vital for survival on Mars as it aids in growing food and sustaining life.",
        "Sand 🏜️": "Martian soil contains sand and dust particles that can be refined and used in construction or glass-making.",
        "Whirlwind 🌬️": "Whirlwinds, or dust devils, are common on Mars and can impact outdoor equipment and habitats.",
        "Tornado 🌪️": "Tornadoes on Mars are not like Earth's, but strong dust storms can disrupt operations.",
        "Soil 🌱": "Soil is needed for growing crops and creating sustainable farming environments on Mars.",
        "Nutrient 🥄": "Nutrients enrich the soil and help plants grow in a hydroponic environment.",
        "Food 🍎": "Producing food on Mars is essential to sustain a human colony without relying on supplies from Earth.",
        "Volcano 🌋": "Volcanoes shape Martian landscapes, and dormant volcanoes could be a source of minerals.",
        "Lava 🎇": "Lava can be cooled and solidified to create a rock-like structure useful in construction.",
        "Glass 🥂": "Glass can be made from sand and is essential for making greenhouse windows and observation domes.",
        "Potion Bottle🔮": "Special containers like potion bottles are needed to store liquids and chemicals safely on Mars.",
        "Rainbow 🌈": "Rainbows could potentially form in the Martian atmosphere if the right conditions of water vapor and sunlight exist.",
        "Sea 🌊": "Large bodies of water could transform the Martian environment, but currently, there are no seas on Mars.",
        "Life 👽": "Finding life or sustaining it on Mars is a critical goal of terraforming efforts.",
        "Science 🔬": "Scientific advancements are the backbone of successfully terraforming and colonizing Mars.",
        "Artificial Atmosphere 🔷": "Creating an artificial atmosphere is essential for pressurizing habitats and making the planet more Earth-like.",
        "Hydroponic Plant 🥀": "Hydroponics allow for soil-less farming, which is ideal in the Martian environment.",
        "Growing Plant 🌲": "Growing plants provide food, oxygen, and help stabilize soil, creating a healthier ecosystem.",
        "Dome 🏠": "Domes create enclosed spaces where humans can live and work on Mars, protecting them from the harsh environment.",
        "Radiation Shield 🛡️": "A radiation shield is vital for protecting humans from the intense cosmic radiation on Mars."
    };

    // Add a reference to the fact box and fact text
    const factBox = document.getElementById("fact-box");
    const factText = document.getElementById("fact-text");

    // Update hint counter display
    function updateHintCounter() {
        hintCounter.textContent = `Hints available: ${availableHints}`;
    }

    // Function to show a hint
    function showHint() {
        if (availableHints > 0) {
            hintText.textContent = hints[Math.floor(Math.random() * hints.length)];
            hintContent.classList.add("expanded");

            availableHints--; // Decrement available hints
            updateHintCounter(); // Update the hint counter display

            // Disable the hint button if no hints are left
            if (availableHints === 0) {
                hintButton.disabled = true;
            }
        }
    }

    // Add event listener to the hint button
    hintButton.addEventListener("click", showHint);

    // Function to award a hint (when enough items are unlocked)
    function awardHint() {
        availableHints++; // Increment available hints
        hintButton.disabled = false; // Enable the hint button
        updateHintCounter(); // Update the hint counter display
    }


     